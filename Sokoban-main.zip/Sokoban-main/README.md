# Sokoban
Proyecto Sokoban para la materia de POO TI22

Por: Torres Fernández Jesús Antonio | 1721110125

# Identificadores
0 - Espacio vacío 

1 - Sokoban - (Alien)

2 - Caja - (Bola 8)

3 - Pared - (Valla)

4 - Meta - (Diamante)

5 - Sokoban en meta 

6 - Caja en meta - (Gema azúl)

7 - Espacio vacío, pero no usable.

# Controles
a - Izquierda

d - Derecha

w - Arriba

s - Abajo

t - Teletransportarse

enter - Lectura del movimiento que se ingrese

# Instrucciones
- El objetivo del juego, es conseguir acomodar todas las cajas (Bolas 8) en todas las metas (Diamantes).
- Debes de declarar el movimiento y presionar enter para leer cada entrada.
- Sólo te puedes mover una casilla por entrada.
- Diviérte mucho! :D
